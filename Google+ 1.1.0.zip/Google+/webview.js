module.exports = (Franz, options) => {
  function getMessages() {
    var badge = 0;
    badge = document.querySelector(".gb_Ec") ? document.querySelector(".gb_Ec").innerHTML : 0;
    Franz.setBadge(badge);
  }
  Franz.loop(getMessages);
